const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "https://m.media-amazon.com/images/I/71oR9w5AjbL._SX522_PIbundle-4,TopRight,0,0_AA522SH20_.jpg",
      name: "Nuts",
      price: "180",
      discount: "25",
    },
    {
      id: 8,
      cover: "https://mirchi.com/os/cdn/content/images/farsan%20namkeen%20chacha%20halwai_medium_0559981.webp",
      name: "Namkeen",
      price: "120",
      discount: "10",
    },
    {
      id: 9,
      cover: "https://sugargeekshow.com/wp-content/uploads/2020/10/baked_donut_recipe_featured.jpg",
      name: "Donut",
      price: "20",
      discount: "50 ",
    },
    
    
    {
      id: 12,
      cover: "https://m.media-amazon.com/images/I/61YarG3bGSL._SL1000_.jpg",
      name: "Knorr Soup",
      price: "100",
      discount: "20 ",
    },
    {
      id: 13,
      cover: "https://c8.alamy.com/comp/2AP3133/collection-of-assorted-culinary-spices-with-names-2AP3133.jpg",
      name: "Spices",
      price: "60",
      discount: "5 ",
    },
    {
      id: 14,
      cover: "https://www.bigbasket.com/media/uploads/p/l/40249762-6_1-storia-100-fruit-juice-mixed-fruit-rich-in-antioxidants-no-added-sugar-no-preservatives-boosts-immunity.jpg",
      name: "Juices",
      price: "120",
      discount: "10",
    },
    {
      id: 11,
      cover: "https://www.goldmedalbakery.com/content/uploads/2019/12/Sandwich-White.jpg",
      name: "Bread",
      price: "80",
      discount: "20 ",
    },
    {
      id: 15,
      cover: "https://www.lalpathlabs.com/blog/wp-content/uploads/2019/01/Fruits-and-Vegetables.jpg",
      name: "Vegetables",
      price: "5",
      discount: "2",
    },
    {
      id: 10,
      cover: "https://www.verybestbaking.com/sites/g/files/jgfbjl326/files/srh_recipes/4bc5edb86285aadc28069f51d9e98974.jpg",
      name: "Cookies",
      price: "999",
      discount: "10 ",
    },
  ],
}
export default Sdata
